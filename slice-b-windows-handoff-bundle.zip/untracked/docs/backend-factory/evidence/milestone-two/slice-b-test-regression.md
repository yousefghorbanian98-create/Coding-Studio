# Slice B Test-Count Regression (Local Unverified)

The earlier local report had 149 unit tests and 21 integration tests. The current worktree temporarily reported 148 unit tests and 21 integration tests.

Exact removed tests from `HEAD` in `src-tauri/src/install/discovery.rs`:

- `try_discover_managed_returns_none_when_missing`
- `try_discover_managed_returns_some_when_found`

These were not accepted as security coverage because they tested the removed lossy API `try_discover_managed(...).ok()` rather than preserving classified production errors. The API was removed to prevent security failures becoming `None`.

Replacement production-behavior tests restored:

- `discover_managed_missing_is_a_production_error_not_absence`
- `discover_managed_returns_canonical_production_candidate`

Both call `discover_managed` directly. The first asserts `ManagedArtifactMissing`; the second asserts the canonical managed candidate and `SourceClassification::Managed`. This restores stronger coverage and raises the current host unit count to 150, before Windows-gated tests are included.

Status: local preflight only; no completion claim.
